-- -- 1
-- insert into employee (email, firstname, lastname, title, password) VALUES ("rohitpatnaik245@gmail.com", "Kantimahanty","Rohit","Mr","123");
-- -- 2
-- insert into employee (email, firstname, lastname, title, password) VALUES ("av36232@gmail.com", "Aman","Verma","Mr","36232");
-- -- 3
-- insert into employee (email, firstname, lastname, title, password) VALUES ("vishalrao@gmail.com", "Vishal","Rao","Mr","prototype1");






-- employee 1's salary

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of Jan",'2022-01-01', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-01-30', 4);

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of Feb",'2022-02-28', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-02-28', 4);

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of March",'2022-03-01', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-03-30', 4);

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of April",'2022-04-01', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-30', 4);

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of May",'2022-05-01', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-05-30', 4);

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of June",'2022-06-01', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-06-30', 4);

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of July",'2022-07-28', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 4);

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of August",'2022-08-01', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 4);

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of Sept",'2022-09-28', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 4);

insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of October",'2022-10-01', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 4);


insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of November",'2022-11-01', 4);
insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 4);

-- employee 2's salary

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of Jan",'2022-01-01',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-01-30',2);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of Feb",'2022-02-28',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-02-28',2);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of March",'2022-03-01',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-03-30',2);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of April",'2022-04-01',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-30',2);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of May",'2022-05-01',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-05-30',2);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of June",'2022-06-01',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-06-30',2);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of July",'2022-07-28',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28',2);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of August",'2022-08-01',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28',2);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of Sept",'2022-09-28',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28',2);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of October",'2022-10-01',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28',2);


-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of November",'2022-11-01',2);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28',2);

-- -- salary of employee 3

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of May",'2022-05-01', 3);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-05-30', 3);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of June",'2022-06-01', 3);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-06-30', 3);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of July",'2022-07-28', 3);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 3);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of August",'2022-08-01', 3);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 3);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of Sept",'2022-09-28', 3);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 3);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of October",'2022-10-01', 3);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 3);

-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Salary of November",'2022-11-01', 3);
-- insert into employee_salary (amount, description, payment_date, employeeid) VALUES (120000, "Bonus",'2022-04-28', 3);
