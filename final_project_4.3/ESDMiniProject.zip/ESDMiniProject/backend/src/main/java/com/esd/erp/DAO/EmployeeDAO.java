package com.esd.erp.DAO;
import com.esd.erp.Bean.Employee;

public interface EmployeeDAO {
    Employee login(Employee employee);
}
