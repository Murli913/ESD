// import './sproductstyle.css';
// const Sproduct = () => {
//     return ( 
//         <div className="sproduct">
//             <section id="prodetails" class="section-p1">
//         <div class="single-pro-image">
//             <img  src="img/Products/f1.jpg" width="100%" id="MainImg" alt="" />
//             <div class="small-img-group">
//                 <div class="small-img-col">
//                     <img src="img/Products/f1.jpg" width="100%" class="small-img" alt="" onclick="showimg(this.src)"/>
//                 </div>
//                 <div class="small-img-col">
//                     <img src="img/Products/f2.jpg" width="100%" class="small-img" alt="" onclick="showimg(this.src)"/>
//                 </div>
//                 <div class="small-img-col">
//                     <img src="img/Products/f3.jpg" width="100%" class="small-img" alt="" onclick="showimg(this.src)"/>
//                 </div>
//                 <div class="small-img-col">
//                     <img src="img/Products/f4.jpg" width="100%" class="small-img" alt="" onclick="showimg(this.src)"/>
//                 </div>
//             </div>
//         </div>
//         <div class="single-pro-details">
//             <h6>Home / T-Shirt</h6>
//             <h4>Men's Fashion T Shirts</h4>
//             <h3>Rs.780.00</h3>
//             <select>
//                 <option>Select Size</option>
//                 <option>XL</option>
//                 <option>XXL</option>
//                 <option>Small</option>
//                 <option>Large</option>
//             </select>
//             <input type="number" value="1"/>
//             <button class="normal">Add To Cart</button>
//             <h4>Product Details</h4>
//             <span>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusantium adipisci veniam, omnis quasi nihil asperiores eum a nemo non fugiat consequuntur molestiae eos inventore porro recusandae tempore quam, repellendus debitis.</span>
//         </div>
//             </section>
//             <section id="product1" class="section-p1">
//         <h2>Featured Products</h2>
//         <p>Winter Collection New Modern Design</p>
//         <div class="pro-container">
//             <div class="pro">
//                 <img src="img/Products/n5.jpg" alt=""/>
//                 <div class="des">
//                     <span>adidas</span>
//                     <h5>Cartoon Astronaut T-Shirts</h5>
//                     <div class="star">
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                     </div>
//                     <h4>Rs.780</h4>
//                 </div>
//                 <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
//             </div>
//             <div class="pro">
//                 <img src="img/Products/n6.jpg" alt=""/>
//                 <div class="des">
//                     <span>adidas</span>
//                     <h5>Cartoon Astronaut T-Shirts</h5>
//                     <div class="star">
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                     </div>
//                     <h4>Rs.780</h4>
//                 </div>
//                 <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
//             </div>
//             <div class="pro">
//                 <img src="img/Products/n7.jpg" alt=""/>
//                 <div class="des">
//                     <span>adidas</span>
//                     <h5>Cartoon Astronaut T-Shirts</h5>
//                     <div class="star">
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                     </div>
//                     <h4>Rs.780</h4>
//                 </div>
//                 <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
//             </div>
//             <div class="pro">
//                 <img src="img/Products/n8.jpg" alt=""/>
//                 <div class="des">
//                     <span>adidas</span>
//                     <h5>Cartoon Astronaut T-Shirts</h5>
//                     <div class="star">
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                         <i class="fas fa-star"></i>
//                     </div>
//                     <h4>Rs.780</h4>
//                 </div>
//                 <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
//             </div>

//         </div>
//             </section>
//             <section id="newsletter" class="section-p1 section-m1">
//         <div class="newstext">
//             <h4>Sign Up For Newsletters</h4>
//             <p>Get E-mail updates about our latest shop and <span>special offers.</span></p>
//         </div>
//         <div class="form">
//             <input type="text" placeholder="Your Email Address"/>
//             <button class="normal">Sign up</button>
//         </div>
//             </section>
//         </div>
//      );
// }
 
// export default Sproduct;
// Sproduct.js
import './sproductstyle.css';
import { useEffect, useState } from 'react';

const Sproduct = () => {
    const [visitedProducts, setVisitedProducts] = useState([]);
    const [products, setProducts] = useState([]);

    useEffect(() => {
        // Fetch products with pvisit equal to 1 from your Express.js server
        fetch('http://localhost:3001/pvisitedProducts')
            .then(response => response.json())
            .then(data => setVisitedProducts(data))
            .catch(error => console.error('Error fetching visited products:', error));
    }, []);
    const handleAddToCart = (productId) => {
        const updatedProducts = products.map(product => {
          if (product.id === productId) {
            return { ...product, CartStatus: 1 };
          }
          return product;
        });
   
        setProducts(updatedProducts);
        fetch('http://localhost:3001/updateCartStatus', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            productId: productId,
            newCartStatus: 1,
          }),
        })
          .then(response => {
            if (!response.ok) {
              throw new Error(`Failed to update CartStatus for product ${productId}`);
            }
            console.log(`CartStatus updated successfully for product ${productId}`);
          })
          .catch(error => console.error('Error updating CartStatus:', error));
      };
      const handleRemoveToCart = (productId) => {
        // Update the cartstatus attribute to 0 and ps to 0 for the clicked product locally
        const updatedProducts = products.map(product => {
          if (product.id === productId) {
            return { ...product, CartStatus: 0, ps: 0 };
          }
          return product;
        });
   
        setProducts(updatedProducts);
   
        // Send a request to update the CartStatus and ps on the server
        fetch('http://localhost:3001/updateCartStatus', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            productId: productId,
            newCartStatus: 0,
          }),
        })
          .then(response => {
            if (!response.ok) {
              throw new Error(`Failed to update CartStatus for product ${productId}`);
            }
            console.log(`CartStatus updated successfully for product ${productId}`);
          })
          .catch(error => console.error('Error updating CartStatus:', error));
      };
    return (
        <div className="sproduct">
            {/* Render product details for visited products */}
            {visitedProducts.map(product => (
                <section key={product.id} id="prodetails" className="section-p1">
                    <div className="single-pro-image">
                        <img src={product.imagesource} width="100%" id="MainImg" alt="" />
                        {/* ... (rest of the code for image gallery) */}
                    </div>
                    <div className="single-pro-details">
                        <h6>Home / T-Shirt</h6>
                        <h4>{product.brandname}'s {product.type}</h4>
                        <h3>{product.price}</h3>
                        <select>
                            <option>Select Size</option>
                            <option>XL</option>
                            <option>XXL</option>
                            <option>Small</option>
                            <option>Large</option>
                        </select>
                        <input type="number" value="1" />
                        <button className="normal" onClick={() => handleAddToCart(product.id)}>Add</button>
                        <button className="normal" onClick={() => handleRemoveToCart(product.id)}>Remove</button>
                        <h4>Product Details</h4>
                        <span>
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                            Accusantium adipisci veniam, omnis quasi nihil asperiores eum
                            a nemo non fugiat consequuntur molestiae eos inventore porro
                            recusandae tempore quam, repellendus debitis.
                        </span>
                    </div>
                </section>
            ))}

            {/* ... (rest of the code) */}
        </div>
    );
}

export default Sproduct;

