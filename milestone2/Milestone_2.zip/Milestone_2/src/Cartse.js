// import './cartstyle.css';
// const Cartse = () => {
//     return ( 
//         <div className="Cartse">
//             <div class="container">
//     <div class="cart">
//       <table>
//         <thead>
//           <tr>
//             <th>Image</th>
//             <th>Product</th>
//             <th>Quantity</th>
//             <th>Price</th>
//             <th>Total</th>
//           </tr>
//         </thead>
//         <tbody>
//           <tr>
//             <td><a href="product.html"><img src="img/Products/f1.jpg" alt="Product 1" class="product-image"/></a></td>
//             <td>Grey Cargo Pant</td>
//             <td>1</td>
//             <td>₹999.00</td>
//             <td>₹999.00</td>
//           </tr>
//           <tr>
//             <td><a href="product.html"><img src="img/Products/f1.jpg" alt="Product 1" class="product-image"/></a></td>
//             <td>Purple Saree</td>
//             <td>2</td>
//             <td>₹1500.00</td>
//             <td>₹3000.00</td>
//           </tr>
//           <tr>
//             <td><img src="img/Products/f1.jpg" alt="Product 1" class="product-image"/></td>
//             <td>Woolen Sweater</td>
//             <td>1</td>
//             <td>₹400.00</td>
//             <td>₹400.00</td>
//           </tr>
//           <tr>
//             <td><img src="img/Products/f1.jpg" alt="Product 1" class="product-image"/></td>
//             <td>Purple Hoodie for Men</td>
//             <td>1</td>
//             <td>₹899.00</td>
//             <td>₹899.00</td>
//           </tr>
//         </tbody>
//       </table>
//     </div>

//     <div class="total-container">
//       <div class="total">
//         <h3>Total: ₹5298.00</h3>
//       </div>

//       <a href="/" class="checkout-btn">Proceed to Checkout</a>
//     </div>
//   </div>
//         </div>
//     ) 
// }
 
// export default Cartse;
