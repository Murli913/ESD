
import './navbarstyle.css';
import React from 'react';
import Navbar from './Navbar';
import Homepage from './Homepage';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Shop from './Shop';
import Sproduct from './Sproduct';
import Profile from './Profile';
import Cart from './Cart';
import Footer from './Footer';

function App() {
  return (
    <Router>
    <div className="App">
      <Navbar/>
      <Switch>
        <Route exact path="/">
        <Homepage></Homepage>
        </Route>
        <Route exact path="/Shop">
          <Shop></Shop>
        </Route>
        <Route exact path='/Sproduct'>
          <Sproduct></Sproduct>
        </Route>
        <Route exact path='/Profile'>
          <Profile></Profile>
        </Route>
        <Route exact path='/Cart'>
          <Cart></Cart>
        </Route>
      </Switch>
      <Footer></Footer>
    </div>
    </Router>
  );
}

export default App;
