// import React, { useState, useEffect } from 'react';
// import { Link } from 'react-router-dom/cjs/react-router-dom.min';
// import './Homestyle.css';

// function Homeproductserver() {
//   const [products, setProducts] = useState([]);

//   useEffect(() => {
//     // Fetch product data from your Express.js server
//     fetch('http://localhost:3001/products')
//       .then(response => response.json())
//       .then(data => setProducts(data))
//       .catch(error => console.error('Error fetching products:', error));
//   }, []);
//   const handleAddToCart = (productId) => {
//     // Update the cartstatus attribute to 1 for the clicked product locally
//     const updatedProducts = products.map(product => {
//       if (product.id === productId) {
//         return { ...product, CartStatus: 1 };
//       }
//       return product;
//     });

//     setProducts(updatedProducts);

//     // Send a request to update the CartStatus on the server
//     fetch('http://localhost:3001/updateCartStatus', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({
//         productId: productId,
//         newCartStatus: 1,
//       }),
//     })
//       .then(response => {
//         if (!response.ok) {
//           throw new Error(`Failed to update CartStatus for product ${productId}`);
//         }
//         console.log(`CartStatus updated successfully for product ${productId}`);
//       })
//       .catch(error => console.error('Error updating CartStatus:', error));
//   };

// //   const updateCartStatus = async(productId) =>
// //   {
// //     try{
// //         const response = await fetch('http://localhost:3001/updateCartStatus', {
// //             method: 'POST',
// //             headers: {
// //                 'Content-Type': 'application/json',
// //             },
// //             body: JSON.stringify({
// //                 productId: productId,
// //                 CartStatus: 1,
// //             }),
// //         });
// //         if (!response.ok){
// //             throw new Error(`Failed to update CartStatus for product ${productId}`);
// //         }
// //         console.log(`CartStatus updated successfully for product ${productId}`);
// //     }
// //     catch (error){
// //         console.error('Error updating CartStatus:', error.message);
// //     }
// //   };
// const handleRemoveToCart = (productId) => {
//     // Update the cartstatus attribute to 1 for the clicked product locally
//     const updatedProducts = products.map(product => {
//       if (product.id === productId) {
//         return { ...product, CartStatus: 0 };
//       }
//       return product;
//     });

//     setProducts(updatedProducts);

//     // Send a request to update the CartStatus on the server
//     fetch('http://localhost:3001/updateCartStatus', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({
//         productId: productId,
//         newCartStatus: 0,
//       }),
//     })
//       .then(response => {
//         if (!response.ok) {
//           throw new Error(`Failed to update CartStatus for product ${productId}`);
//         }
//         console.log(`CartStatus updated successfully for product ${productId}`);
//       })
//       .catch(error => console.error('Error updating CartStatus:', error));
//   };

//   return (
//     <div className="Homeproductserver">
//       <div class="pro-container">
//             {
//                 products.map( record => {
//                     return(
//                         <div className="pro" key={record.id}>
//                         <button className='white'><img src={ record.imagesource } alt=""/></button>
//                         <div className="des">
//                             <span>{ record.brandname}</span>
//                             <h5>{ record.type }</h5>
//                             <div class="star">
//                                 <i class="fas fa-star"></i>
//                                 <i class="fas fa-star"></i>
//                                 <i class="fas fa-star"></i>
//                                 <i class="fas fa-star"></i>
//                                 <i class="fas fa-star"></i>
//                         </div>
//                         <h4>{ record.price }</h4>
//                         <p>Cart Status:{ record.CartStatus}</p>
//                         <button className='normal' onClick={() => handleAddToCart(record.id)}>Add</button> 
//                         <button className='normal' onClick={() => handleRemoveToCart(record.id)}>Del</button>
//                         </div>
//                         <Link to ="/Sproduct"><i class="fa-solid fa-cart-shopping csh"></i></Link>
//                         </div>
//                     )
//                 })
//             }
//             </div>
//     </div>
//   );
// }

// 2nd code Cart Successful

// export default Homeproductserver;
// import React, { useState, useEffect } from 'react';
// import { Link } from 'react-router-dom/cjs/react-router-dom.min';
// import './Homestyle.css';

// function Homeproductserver() {
//   const [products, setProducts] = useState([]);

//   useEffect(() => {
//     // Fetch product data from your Express.js server
//     fetch('http://localhost:3001/products')
//       .then(response => response.json())
//       .then(data => setProducts(data))
//       .catch(error => console.error('Error fetching products:', error));
//   }, []);

//   const handleAddToCart = (productId) => {
//     // Update the cartstatus attribute to 1 for the clicked product locally
//     const updatedProducts = products.map(product => {
//       if (product.id === productId) {
//         return { ...product, CartStatus: 1,ps: 0 };
//       }
//       return product;
//     });

//     setProducts(updatedProducts);

//     // Send a request to update the CartStatus and ps on the server
//     fetch('http://localhost:3001/updateCartStatus', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({
//         productId: productId,
//         newCartStatus: 1,
//         newPs:0,
//       }),
//     })
//       .then(response => {
//         if (!response.ok) {
//           throw new Error(`Failed to update CartStatus for product ${productId}`);
//         }
//         console.log(`CartStatus updated successfully for product ${productId}`);
//       })
//       .catch(error => console.error('Error updating CartStatus:', error));

//     // Redirect to the Sproduct route
//   };
//   const handleRemoveToCart = (productId) => {
//     // Update the cartstatus attribute to 0 and ps to 0 for the clicked product locally
//     const updatedProducts = products.map(product => {
//       if (product.id === productId) {
//         return { ...product, CartStatus: 0, ps: 0 };
//       }
//       return product;
//     });

//     setProducts(updatedProducts);

//     // Send a request to update the CartStatus and ps on the server
//     fetch('http://localhost:3001/updateCartStatus', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({
//         productId: productId,
//         newCartStatus: 0,
//       }),
//     })
//       .then(response => {
//         if (!response.ok) {
//           throw new Error(`Failed to update CartStatus for product ${productId}`);
//         }
//         console.log(`CartStatus updated successfully for product ${productId}`);
//       })
//       .catch(error => console.error('Error updating CartStatus:', error));
//   };

//   return (
//     <div className="Homeproductserver">
//       <div className="pro-container">
//         {products.map(record => (
//           <div className="pro" key={record.id}>
//             <button className='white'>
//               <img src={record.imagesource} alt="" />
//             </button>
//             <div className="des">
//               <span>{record.brandname}</span>
//               <h5>{record.type}</h5>
//               <div className="star">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//               </div>
//               <h4>{record.price}</h4>
//               <p>Cart Status: {record.CartStatus}</p>
//               <button className='normal' onClick={() => handleAddToCart(record.id)}>Add</button>
//               <button className='normal' onClick={() => handleRemoveToCart(record.id)}>Del</button>
//               <button className='normal'>View</button>
//             </div>
//             <Link to="/Sproduct"><i className="fa-solid fa-cart-shopping csh"></i></Link>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default Homeproductserver;

// Homeproductserver.js
import React, { useState, useEffect } from 'react';
import { Link, useHistory } from 'react-router-dom';
import './Homestyle.css';

function Homeproductserver() {
    const [products, setProducts] = useState([]);
    const history = useHistory();

    useEffect(() => {
        // Fetch product data from your Express.js server
        fetch('http://localhost:3001/products')
            .then(response => response.json())
            .then(data => setProducts(data))
            .catch(error => console.error('Error fetching products:', error));
    }, []);
    const handleAddToCart = (productId) => {
     const updatedProducts = products.map(product => {
       if (product.id === productId) {
         return { ...product, CartStatus: 1 };
       }
       return product;
     });

     setProducts(updatedProducts);
     fetch('http://localhost:3001/updateCartStatus', {
       method: 'POST',
       headers: {
         'Content-Type': 'application/json',
       },
       body: JSON.stringify({
         productId: productId,
         newCartStatus: 1,
       }),
     })
       .then(response => {
         if (!response.ok) {
           throw new Error(`Failed to update CartStatus for product ${productId}`);
         }
         console.log(`CartStatus updated successfully for product ${productId}`);
       })
       .catch(error => console.error('Error updating CartStatus:', error));
   };
   const handleRemoveToCart = (productId) => {
     // Update the cartstatus attribute to 0 and ps to 0 for the clicked product locally
     const updatedProducts = products.map(product => {
       if (product.id === productId) {
         return { ...product, CartStatus: 0, ps: 0 };
       }
       return product;
     });

     setProducts(updatedProducts);

     // Send a request to update the CartStatus and ps on the server
     fetch('http://localhost:3001/updateCartStatus', {
       method: 'POST',
       headers: {
         'Content-Type': 'application/json',
       },
       body: JSON.stringify({
         productId: productId,
         newCartStatus: 0,
       }),
     })
       .then(response => {
         if (!response.ok) {
           throw new Error(`Failed to update CartStatus for product ${productId}`);
         }
         console.log(`CartStatus updated successfully for product ${productId}`);
       })
       .catch(error => console.error('Error updating CartStatus:', error));
   };
    const handleViewProduct = (productId) => {
        // Update the pvisit attribute to 1 for the clicked product
        fetch('http://localhost:3001/updatePVisit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                productId: productId,
                pvisit: 1,
            }),
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Failed to update pvisit for product ${productId}`);
                }
                console.log(`pvisit updated successfully for product ${productId}`);
                // Redirect to Sproduct.js after updating pvisit
                history.push('/Sproduct');
            })
            .catch(error => console.error('Error updating pvisit:', error.message));
    };

    return (
        <div className="Homeproductserver">
            <div className="pro-container">
                {products.map(record => (
                    <div key={record.id} className="pro">
                        <img src={record.imagesource} alt="" />
                        <div className="des">
                            <span>{record.brandname}</span>
                            <h5>{record.type}</h5>
                            <div className="star">
                                <i className="fas fa-star"></i>
                                <i className="fas fa-star"></i>
                                <i className="fas fa-star"></i>
                                <i className="fas fa-star"></i>
                                <i className="fas fa-star"></i>
                            </div>
                            <h4>{record.price}</h4>
                            <p>Cart Status: {record.CartStatus}</p>
                            <button className='normal' onClick={() => handleAddToCart(record.id)}>Add</button>
                            <button className='normal' onClick={() => handleRemoveToCart(record.id)}>Del</button>
                            <button className='normal' onClick={() => handleViewProduct(record.id)}>View</button>
                        </div>
                        <Link to="/Sproduct"><i className="fa-solid fa-cart-shopping csh"></i></Link>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Homeproductserver;

