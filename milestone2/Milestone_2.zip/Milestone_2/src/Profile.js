import './profilestyle.css';
const Profile = () => {
    return ( 
        <div className="profile">
            <main>
    <section className="profile-info">
      <img src="img/shanks.jpg" alt="Balayya Babu"/>
      <h2>Shanks</h2>
      <p>Email: Shanks@gmail.com</p>
      <p>Location: 45 Jubilee Hills Road, Hyderabad - 500033</p>
    </section>

    <section className="order-history">
      <h2>Order History</h2>
      <ul>
        <li>
          <p>Order: #12345</p>
          <p>Date: 2023-11-09</p>
          <p>Total: $50.00</p>
        </li>
        <li>
          <p>Order: #67890</p>
          <p>Date: 2022-11-09</p>
          <p>Total: $150.00</p>
        </li>
        <li>
          <p>Order: #83458</p>
          <p>Date: 2021-11-09</p>
          <p>Total: $250.00</p>
        </li>
      </ul>
    </section>
  </main>
        </div>
     );
}
 
export default Profile;