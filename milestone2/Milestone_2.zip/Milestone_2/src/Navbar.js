// import "./navbarstyle.css"
// import React from "react";
// import { Link } from 'react-router-dom';

// const Navbar = () => {
    
//     return ( 
//         <section id="header">
//             <img src="/images/LogoOM.JPG" width= "100px" height="80px" alt="" />
//             <div>
//                 <ul id="navbar">
//                 <li><Link to = "/">Home</Link></li>
//                 <li><Link to = "/Shop">Shop</Link></li>
//                 <li><a href="/"> blog</a></li>
//                 <li><a href="/"> about</a></li>
//                 <li><Link to = "/Profile">Profile</Link></li>
//                 <li><Link to = "/Cart">Cart</Link></li>
//                 </ul>
//             </div>
//         </section>
//      );
// }
// export default Navbar;

// Navbar.js
import "./navbarstyle.css";
import React from "react";
import { Link } from 'react-router-dom';

const Navbar = () => {
    
    const handleHomeClick = async () => {
        try {
            // Make a request to update pvisit attribute for all products
            const response = await fetch('http://localhost:3001/updateAllPVisit', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    pvisit: 0,
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to update pvisit for all products');
            }

            console.log('pvisit updated successfully for all products');
        } catch (error) {
            console.error('Error updating pvisit:', error.message);
        }
    };

    return ( 
        <section id="header">
            <img src="/images/LogoOM.JPG" width="100px" height="80px" alt="" />
            <div>
                <ul id="navbar">
                    <li><Link to="/" onClick={handleHomeClick}>Home</Link></li>
                    <li><Link to="/Shop">Shop</Link></li>
                    <li><a href="/"> blog</a></li>
                    <li><a href="/"> about</a></li>
                    <li><Link to="/Profile">Profile</Link></li>
                    <li><Link to="/Cart">Cart</Link></li>
                </ul>
            </div>
        </section>
     );
}

export default Navbar;

