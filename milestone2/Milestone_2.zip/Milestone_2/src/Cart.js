// // Cart.js
// import React, { useState, useEffect } from 'react';
// import './cstyle.css';

// function Cart() {
//   const [cartProducts, setCartProducts] = useState([]);

//   useEffect(() => {
//     // Fetch cart products with CartStatus = 1 from your Express.js server
//     fetch('http://localhost:3001/cartProducts')
//       .then(response => response.json())
//       .then(data => setCartProducts(data))
//       .catch(error => console.error('Error fetching cart products:', error));
//   }, []);

//   // Calculate the total price of all products in the cart
//   const totalPrice = cartProducts.reduce((total, product) => total + parseFloat(product.price.replace('Rs.', '')), 0);

//   return (
//     <div className="cart-container">
//       <h1 className="cart-heading">Cart Products</h1>
//       <ul className="cart-list">
//         {cartProducts.map(product => (
//           <li key={product.id} className="cart-item">
//             <img src={product.imagesource} alt={product.type} className="cart-image" />
//             <div className="cart-details">
//               <p className="cart-brand">Brand: {product.brandname}</p>
//               <p className="cart-type">Type: {product.type}</p>
//               <p className="cart-price">Price: {product.price}</p>
//               <p className="cart-status">Cart Status: {product.CartStatus}</p>
//             </div>
//           </li>
//         ))}
//       </ul>
//       <div className="cart-total">
//         <p>Total Price: Rs. {totalPrice.toFixed(2)}</p>
//       </div>
//       <div className="checkout-button">
//           <button className="checkout-btn">Checkout</button>
//       </div>
//     </div>
//   );
// }

// export default Cart;


// Cart.js
import React, { useState, useEffect } from 'react';
import './cstyle.css';

function Cart() {
  const [cartProducts, setCartProducts] = useState([]);

  useEffect(() => {
    // Fetch cart products with CartStatus = 1 from your Express.js server
    fetch('http://localhost:3001/cartProducts')
      .then(response => response.json())
      .then(data => {
        const cartProductsWithQuantity = data.map(product => ({ ...product, quantity: 1 }));
        setCartProducts(cartProductsWithQuantity);})
      .catch(error => console.error('Error fetching cart products:', error));
  }, []);

  // Calculate the total price of all products in the cart
  const totalPrice = cartProducts.reduce((total, product) => total + (parseFloat(product.price.replace('Rs.', '')) * product.quantity), 0);

  // Function to handle quantity change
  const handleQuantityChange = (productId, newQuantity) => {
    // Update the quantity for the clicked product
    const updatedCartProducts = cartProducts.map(product => {
      if (product.id === productId) {
        return { ...product, quantity: newQuantity };
      }
      return product;
    });

    setCartProducts(updatedCartProducts);
  };

  return (
    <div className="cart-container">
      <h1 className="cart-heading">Cart Products</h1>
      <ul className="cart-list">
        {cartProducts.map(product => (
          <li key={product.id} className="cart-item">
            <img src={product.imagesource} alt={product.type} className="cart-image" />
            <div className="cart-details">
              <p className="cart-brand">Brand: {product.brandname}</p>
              <p className="cart-type">Type: {product.type}</p>
              <p className="cart-price">Price: {product.price}</p>
              <p className="cart-quantity">Quantity: 
                <input 
                  type="number" 
                  value={product.quantity} 
                  onChange={(e) => handleQuantityChange(product.id, e.target.value)}
                />
              </p>
              <p className="cart-status">Cart Status: {product.CartStatus}</p>
            </div>
          </li>
        ))}
      </ul>
      <div className="cart-total">
        <p>Total Price: Rs. {totalPrice.toFixed(2)}</p>
      </div>
      <div className="checkout-button">
        <button className="checkout-btn">Checkout</button>
      </div>
    </div>
  );
}

export default Cart;
