import './Shopstyle.css';
const Shop = () => {
    return ( 
        <div className="shop">
            <section id="page-header">
        <h2>#stayhome</h2>
        <p>Save more with coupons & upto 70% off!</p>
            </section>
            <section id="product1" class="section-p1">
        <div class="pro-container">
            <div class="pro">
                <img src="img/Products/f1.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="sproduct.html"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/f2.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/f3.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/f4.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/f5.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/f6.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/f7.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/f8.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/n1.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/n2.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/n3.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/n4.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/n5.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/n6.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/n7.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
            <div class="pro">
                <img src="img/Products/n8.jpg" alt=""/>
                <div class="des">
                    <span>adidas</span>
                    <h5>Cartoon Astronaut T-Shirts</h5>
                    <div class="star">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h4>Rs.780</h4>
                </div>
                <a href="/"><i class="fa-solid fa-cart-shopping csh"></i></a>
            </div>
        </div>
            </section>
            <section id="pagination" class="section-p1">
        <a href="/">1</a>
        <a href="/">2</a>
        <a href="/"><i class="fa-solid fa-arrow-right"></i></a>
            </section>
            <section id="newsletter" class="section-p1 section-m1">
        <div class="newstext">
            <h4>Sign Up For Newsletters</h4>
            <p>Get E-mail updates about our latest shop and <span>special offers.</span></p>
        </div>
        <div class="form">
            <input type="text" placeholder="Your Email Address"/>
            <button class="normal">Sign up</button>
        </div>
            </section>
        </div>
     );
}
 
export default Shop;