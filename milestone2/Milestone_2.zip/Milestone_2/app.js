const express = require('express')
var bodyParser = require('body-parser')
 
// create application/json parser
var jsonParser = bodyParser.json()
 
// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false })

const app = express()
var cors = require('cors')
const port = 3001

app.use(cors());
const products = [
    {
        "id" :1,
        "imagesource": "img/Products/f1.jpg",
        "brandname":"Adidas",
        "type":"Cartoon Astronaut T-shirts",
        "price":"Rs.780.00",
	"CartStatus":0,
	"pvisit":0
    },
    {
        "id" :2,
        "imagesource": "img/Products/f2.jpg",
        "brandname":"Puma",
        "type":" Aesthetic T-shirts",
        "price":"Rs.700.00",
	"CartStatus":0,
	"pvisit":0
    },
    {
        "id" :3,
        "imagesource": "img/Products/f3.jpg",
        "brandname":"Allen Solly",
        "type":"Hawai T-shirts",
        "price":"Rs.500.00",
	"CartStatus":0,
	"pvisit":0
    },
    {
        "id" :4,
        "imagesource": "img/Products/f4.jpg",
        "brandname":"Peter England",
        "type":"Casual Summer T-shirts",
        "price":"Rs.600.00",
	"CartStatus":0,
	"pvisit":0
    },
    {
        "id" :5,
        "imagesource": "img/Products/f5.jpg",
        "brandname":"Puma",
        "type":"Casual T-shirts",
        "price":"Rs.450.00",
	"CartStatus":0,
	"pvisit":0
    },
    {
        "id" :6,
        "imagesource": "img/Products/f6.jpg",
        "brandname":"Twills",
        "type":"Aesthtic Jacket",
        "price":"Rs.1200.00",
	"CartStatus":0,
	"pvisit":0
    },
    {
        "id" :7,
        "imagesource": "img/Products/f7.jpg",
        "brandname":"Indigo",
        "type":"Pants",
        "price":"Rs.400.00",
	"CartStatus":0,
	"pvisit":0
    },
    {
        "id" :8,
        "imagesource": "img/Products/f8.jpg",
        "brandname":"Vanhuessen",
        "type":"Cartoon Half-shirts",
        "price":"Rs.1300.00",
	"CartStatus":0,
	"pvisit":0
    }
];
app.get('/', (req, res) => {
  console.log("/ invoked");
  res.send('Hello World!')
})

app.get('/products', (req,res) => {
  console.log("/products invoked");
  res.send(JSON.stringify(products));
  // res.sendStatus(404);
})
app.get('/pvisitedProducts', (req, res) => {
    // Filter products with pvisit equal to 1
    const visitedProducts = products.filter(product => product.pvisit === 1);
    res.send(JSON.stringify(visitedProducts));
});
app.get('/cartProducts', (req, res) => {
  // Filter products with CartStatus equal to 1
  const cartProducts = products.filter(product => product.CartStatus === 1);
  res.send(JSON.stringify(cartProducts));
});
app.post('/updateCartStatus', jsonParser, (req, res) => {
  const productId = req.body.productId;
  const newCartStatus = req.body.newCartStatus; // Add this line

  // Update the CartStatus and ps attributes for the clicked product on the server side
  const updatedProducts = products.map(product => {
    if (product.id === productId) {
      return { ...product, CartStatus: newCartStatus };
    }
    return product;
  });

  // Update the products array with the new data
  products.length = 0;
  updatedProducts.forEach(product => {
    products.push(product);
  });

  res.sendStatus(200);
});

app.post('/updatePVisit', jsonParser, (req, res) => {
  const productId = req.body.productId;
  const newPVisit = req.body.pvisit;

  // Update the pvisit attribute for the clicked product on the server side
  const updatedProducts = products.map(product => {
    if (product.id === productId) {
      return { ...product, pvisit: newPVisit };
    }
    return product;
  });

  // Update the products array with the new data
  products.length = 0;
  updatedProducts.forEach(product => {
    products.push(product);
  });

  res.sendStatus(200);
});

app.post('/updateAllPVisit', jsonParser, (req, res) => {
  const newPVisitValue = req.body.pvisit;

  // Update the pvisit attribute for all products on the server side
  const updatedProducts = products.map(product => ({
    ...product,
    pvisit: newPVisitValue,
  }));

  // Update the products array with the new data
  products.length = 0;
  updatedProducts.forEach(product => {
    products.push(product);
  });

  res.sendStatus(200);
});

// Add this route to your Express.js server code

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})